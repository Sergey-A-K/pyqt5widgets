#include "tableviewnew3d.h"
#include <QPainter>
#include <QMouseEvent>






class TableViewNew3D : public QWidget
{
	Q_OBJECT
public:
	explicit TableViewNew3D(QWidget *parent = 0);
	void clear();
	void setRowCount(int count);
	void setColumnCount(int count);
	void setItem(int row,int column,QString text);
	void rebuildTable();
	int rowCount() { return self.m_rowCount; }
	int columnCount() { return self.m_columnCount; }
	QList<QPoint> selectedItems() { QList<QPoint> l; l.append(currentCell); return l; }
	QString item(int row,int column);
	void setXAxis(int index,QString number);
	void setYAxis(int index,QString number);
	QString xAxis(int index);
	QString yAxis(int index);
	void addHotkey(int key,Qt::KeyboardModifier modifier);
	void setTracingValue(double x,double y);
	void setTracingEnabled(bool enabled) { self.m_traceEnabled = enabled; update(); }
	void setMaxValues(double maxx,double maxy,double maxz);
private:
	double self.m_maxXValue;
	double self.m_maxYValue;
	double self.m_maxZValue;
	void drawCell(QPainter *painter,int cellx,int celly,QString text,bool highlight);
	QTimer *self.m_updateTimer;
	double self.m_traceX;
	double self.m_traceY;
	bool self.m_traceEnabled;
	QList<QPair<int,Qt::KeyboardModifier> > self.m_hotkeyMap;
	double self.m_itemHeight;
	double self.m_itemWidth;
	void resizeEvent(QResizeEvent *evt);
	void paintEvent (QPaintEvent *evt);
	QList<QString> xaxis;
	QList<QString> yaxis;
	QList<QList<QString> > values;
	QList<QPair<int, int> > self.m_selectionList;
	void mouseMoveEvent(QMouseEvent *evt);
	void mousePressEvent(QMouseEvent *evt);
	void mouseReleaseEvent(QMouseEvent *evt);
	int self.m_x;
	int self.m_y;
	QList<QList<int> > self.m_highlightList;
	void keyPressEvent(QKeyEvent *evt);
	QPoint currentCell;
	QPoint startSelectCell;
	bool multiSelect;
	int self.m_rowCount;
	int self.m_columnCount;
	void rebuildtable();
	bool self.m_inEdit;
	QString self.m_editText;

signals:
	void keyPressed(int key);
	void hotKeyPressed(int key,Qt::KeyboardModifier modifier);
	void itemChangeRequest(int row,int column,QString text);
	void currentSelectionChanged(QList<QPair<int,int> > selectionList);
public slots:




class QNeedleIndicator(QWidget):

    def __init__(self, minVal = 0, maxVal = 100, majorTicks = 11, minorTicks = 8, gap_angle = 90):
        super().__init__()


TableViewNew3D::TableViewNew3D(QWidget *parent) : QWidget(parent)
{
	self.m_itemHeight = 30;
	self.m_itemWidth = 60;
	multiSelect = false;
	self.m_rowCount = 16;
	self.m_columnCount = 16;
	setFocusPolicy(Qt::ClickFocus);
	self.m_traceEnabled = false;

//         #self.timer   = QTimer()
//         #self.timer.setInterval(100)
//         #self.timer.timeout.connect(self.animate)

	self.m_updateTimer = new QTimer(this);
	connect(self.m_updateTimer,SIGNAL(timeout()),this,SLOT(update()));
	self.m_updateTimer->start(100);
	self.m_inEdit = false;
	qRegisterMetaType<QList<QPair<int,int> > >("QList<QPair<int,int> >");

}
void TableViewNew3D::setTracingValue(double x,double y)
{
	self.m_traceX = x;
	self.m_traceY = y;
}

void TableViewNew3D::addHotkey(int key,Qt::KeyboardModifier modifier)
{
	self.m_hotkeyMap.append(QPair<int,Qt::KeyboardModifier>(key,modifier));
}

void TableViewNew3D::resizeEvent(QResizeEvent *evt)
{
	self.m_itemWidth = this->width() / (self.m_columnCount + 1);
	self.m_itemHeight = this->height() / (self.m_rowCount + 1);
	this->update();
}

void TableViewNew3D::setXAxis(int index,QString number)
{
	xaxis[index] = number;
}

void TableViewNew3D::setYAxis(int index,QString number)
{
	yaxis[index] = number;
}
QString TableViewNew3D::xAxis(int index)
{
	return xaxis[index];
}

QString TableViewNew3D::yAxis(int index)
{
	return yaxis[index];
}

void TableViewNew3D::clear()
{
	//Clear everything out
	yaxis.clear();
	self.m_highlightList.clear();
	values.clear();
	xaxis.clear();
}
void TableViewNew3D::rebuildTable()
{
	yaxis.clear();
	self.m_highlightList.clear();
	values.clear();
	xaxis.clear();
	for (int y=0;y<self.m_rowCount;y++)
	{
		yaxis.append("0");
		QList<QString> row;
		QList<int> highlightrow;
		highlightrow.append(0); //For the Y column
		for (int x=0;x<self.m_columnCount;x++)
		{
			xaxis.append("0");
			row.append("0");
			highlightrow.append(0);
		}
		self.m_highlightList.append(highlightrow);
		if (y == 0)
		{
			self.m_highlightList.append(highlightrow); //Double add it for the last row
		}
		highlightrow.clear();
		values.append(row);
	}

}

void TableViewNew3D::setRowCount(int count)
{
	if (count < self.m_rowCount)
	{
		//Reducing the number of rows
	}
	else if (count > self.m_rowCount)
	{

	}
	else
	{
		//Row count stays the same
		return;
	}
	//Assume row count is changing from 0 to whatever
	self.m_rowCount = count;
	rebuildTable();
}
void TableViewNew3D::setItem(int row,int column,QString text)
{
	if (row == -1)
	{
		//X Axis
		if (column == -1)
		{
			//Ignore
			return;
		}
		setXAxis(column,text);
	}
	else if (column == -1)
	{
		//Y Axis
		setYAxis(row,text);
	}
	else
	{
		values[row][column] = text;
	}
	if (currentCell.x() == row && currentCell.y() == column)
	{
		emit currentSelectionChanged(self.m_selectionList);
	}
	update();
}
QString TableViewNew3D::item(int row,int column)
{
	if (row == -1)
	{
		//XAxis
		if (column == -1)
		{
			return "";
		}
		return xaxis[column];
	}
	else if (column == -1)
	{
		return yaxis[row];
	}
	else
	{
		return values[row][column];
	}
}
void TableViewNew3D::setColumnCount(int count)
{
	self.m_columnCount = count;
	rebuildTable();
}
void TableViewNew3D::setMaxValues(double maxx,double maxy,double maxz)
{
	self.m_maxXValue = maxx;
	self.m_maxYValue = maxy;
	self.m_maxZValue = maxz;
}

void TableViewNew3D::drawCell(QPainter *painter,int cellx,int celly,QString text,bool highlight)
{
	QPen oldpen = painter->pen();
	QPen pen = oldpen;
	if (highlight)
	{
		pen.setColor(QColor::fromRgb(0,0,255));
		pen.setWidth(2);
		painter->setPen(pen);
		painter->drawRect((cellx*self.m_itemWidth)+2,(celly*self.m_itemHeight)+2,self.m_itemWidth-2,self.m_itemHeight-2);
	}
	else
	{
		pen.setColor(QColor::fromRgb(0,0,0));
		painter->setPen(pen);
		painter->drawRect((cellx*self.m_itemWidth)+1,(celly*self.m_itemHeight)+1,self.m_itemWidth-1,self.m_itemHeight-1);
	}

	pen.setColor(QColor::fromRgb(0,0,0));

	//For now, disable coloring for axis
	if (highlight || cellx == 0 || celly == self.m_rowCount)
	{
		painter->fillRect((self.m_itemWidth*cellx)+4,(self.m_itemHeight*celly)+4,self.m_itemWidth-5,self.m_itemHeight-5,QColor::fromRgb(255,255,255));
	}
	else
	{
		double val = text.toDouble();
		double max = 255;
		if (cellx == 0)
		{
			max = self.m_maxYValue;
		}
		else if (celly == self.m_rowCount)
		{
			max = self.m_maxXValue;
		}
		else
		{
			max = self.m_maxZValue;
		}

		if (val < max/4.0)
		{
			QColor bgcolor = QColor::fromRgb(0,(255*((val)/(max/4.0))),255);
			painter->fillRect((self.m_itemWidth*cellx)+2,(self.m_itemHeight*celly)+2,self.m_itemWidth-2,self.m_itemHeight-2,bgcolor);
		}
		else if (val < ((max/4.0)*2))
		{
			QColor bgcolor = QColor::fromRgb(0,255,255-(255*((val-((max/4.0)))/(max/4.0))));
			painter->fillRect((self.m_itemWidth*cellx)+2,(self.m_itemHeight*celly)+2,self.m_itemWidth-2,self.m_itemHeight-2,bgcolor);
		}
		else if (val < ((max/4.0)*3))
		{
			QColor bgcolor = QColor::fromRgb((255*((val-((max/4.0)*2))/(max/4.0))),255,0);
			painter->fillRect((self.m_itemWidth*cellx)+2,(self.m_itemHeight*celly)+2,self.m_itemWidth-2,self.m_itemHeight-2,bgcolor);
		}
		else
		{
			QColor bgcolor = QColor::fromRgb(255,255-(255*((val-((max/4.0)*3))/(max/4.0))),0);
			painter->fillRect((self.m_itemWidth*cellx)+2,(self.m_itemHeight*celly)+2,self.m_itemWidth-2,self.m_itemHeight-2,bgcolor);
		}
	}


	painter->setPen(pen);
	int width = painter->fontMetrics().width(text);
	painter->drawText(((cellx)*self.m_itemWidth) + (self.m_itemWidth/2.0) - (width / 2.0),(celly)*self.m_itemHeight + ((self.m_itemHeight/2.0)-2) + (painter->fontMetrics().height()/2.0),text);
	painter->setPen(oldpen);
}

void TableViewNew3D::paintEvent (QPaintEvent *evt)
{
	Q_UNUSED(evt)
	QPainter painter(this);
	painter.setPen(QColor::fromRgb(0,0,0));
	painter.drawRect(0,0,width()-1,height()-1);
	//item width = 40
	//item height = 20
	double self.m_currentTrace = 0;
	double drawTraceY = 0;
	bool foundy = false;

	double drawTraceX = 0;
	bool foundx = false;

	for (int y=0;y<self.m_rowCount;y++)
	{
		if (currentCell.x() == -1 && currentCell.y() == y)
		{
			if (self.m_inEdit)
			{
				drawCell(&painter,0,y,self.m_editText,true);
			}
			else
			{
				drawCell(&painter,0,y,yaxis.at(y),true);
			}
		}
		else
		{
			drawCell(&painter,0,y,yaxis.at(y),false);
		}
		painter.setPen(QColor::fromRgb(0,0,0));
		if (self.m_traceEnabled)
		{
			self.m_currentTrace = yaxis.at(y).toDouble();
			if (self.m_traceY < self.m_currentTrace)
			{
				if (y == self.m_rowCount-1)
				{
					double curr = yaxis.at(y).toDouble();
					double next = 0;
					if (self.m_traceY < next)
					{
						//The trace is below the line, limit it to the line
						drawTraceY = (y * self.m_itemHeight) + ((self.m_itemHeight));
						foundy = true;
					}
					else
					{
						//The trace is above the line
						double percent = (next - self.m_traceY) / (next - curr);
						drawTraceY = ((y * self.m_itemHeight) + (self.m_itemHeight)) - (percent * (self.m_itemHeight/2.0));
						foundy = true;

					}
				}
			}
			else if (!foundy)
			{
				double prev = 0;
				double lastY = 0;
				if (y == 0)
				{
					//Value is between the top and null values
					prev = yaxis.at(y).toDouble() - ((yaxis.at(y+1).toDouble() - yaxis.at(y).toDouble()) / 2.0);
					lastY = 0;
				}
				else
				{
					prev = yaxis.at(y-1).toDouble();
					lastY = (y-1)*self.m_itemHeight + ((self.m_itemHeight/2.0)-2);
				}
				//Between the current trace and the last one, we have our value

				double diff = prev - self.m_currentTrace;
				double percent =(prev - self.m_traceY) / diff;
				double currentY = (y)*self.m_itemHeight + ((self.m_itemHeight/2.0)-2);
				drawTraceY = (lastY + (percent * (currentY - lastY)));
				if (drawTraceY < 0)
				{
					//Cap it at 0
					drawTraceY = 0;
				}
				foundy = true;
			}
		}
	}
	for (int x=0;x<self.m_columnCount;x++)
	{
		if (currentCell.y() == -1 && currentCell.x() == x)
		{
			if (self.m_inEdit)
			{
				drawCell(&painter,x+1,self.m_rowCount,self.m_editText,true);
			}
			else
			{
				drawCell(&painter,x+1,self.m_rowCount,xaxis.at(x),true);
			}
		}
		else
		{
			drawCell(&painter,x+1,self.m_rowCount,xaxis.at(x),false);
		}
		painter.setPen(QColor::fromRgb(0,0,0));

		if (self.m_traceEnabled)
		{
			self.m_currentTrace = xaxis.at(x).toDouble();
			if (self.m_traceX > self.m_currentTrace)
			{
				if (x == self.m_columnCount-1)
				{
					double prev = xaxis.at(x-1).toDouble();
					double curr = xaxis.at(x).toDouble();
					double next = curr + ((curr - prev) / 2.0);
					if (self.m_traceX > next)
					{
						//Trace is at or beyond the end
						drawTraceX = self.m_itemWidth + (x * self.m_itemWidth) + (self.m_itemWidth);
						foundx = true;
					}
					else
					{
						double percent = (self.m_traceX - curr) / (next - curr);
						drawTraceX = (((x+1) * self.m_itemWidth) + (self.m_itemWidth / 2.0)) + (percent * (self.m_itemWidth/2.0));
						foundx = true;
					}
				}
			}
			else if (!foundx)
			{
				double prev = 0;
				double lastx;
				if (x == 0)
				{
					//Value is between the top and null values
					//prev = xaxis.at(x).toDouble() - ((xaxis.at(x+1).toDouble() - xaxis.at(x).toDouble()));
					prev = 0;
					lastx = self.m_itemWidth;
				}
				else
				{
					prev = xaxis.at(x-1).toDouble();
					lastx = self.m_itemWidth + ((x-1) * self.m_itemWidth) + (self.m_itemWidth / 2.0);
				}
				//Between the current trace and the last one, we have our value

				double diff = self.m_currentTrace - prev;
				double percent =(self.m_traceX - prev) / diff;
				//Percent is a 0.0-1.0 of where the trace should lie,between i-1, and i;
				double currentX = self.m_itemWidth + ((x)*self.m_itemWidth) + ((self.m_itemWidth/2.0));
				drawTraceX = (lastx + (percent * (currentX - lastx)));
				if (drawTraceX < self.m_itemWidth)
				{
					drawTraceX = self.m_itemWidth;
				}
				foundx = true;
			}
		}


	}

	for (int y=0;y<self.m_rowCount;y++)
	{
		for (int x=0;x<self.m_columnCount;x++)
		{
			if (currentCell.y() == y && currentCell.x() == x)
			{
				if (self.m_inEdit)
				{
					drawCell(&painter,x+1,y,self.m_editText,true);
				}
				else
				{
					drawCell(&painter,x+1,y,values.at(y).at(x),true);
				}

			}
			else
			{
				drawCell(&painter,x+1,y,values.at(y).at(x),false);
			}
		}
	}
	if (foundy && foundx && self.m_traceEnabled)
	{
		QPen pen = painter.pen();
		pen.setWidth(5);
		pen.setColor(QColor::fromRgb(255,255,0));
		painter.setPen(pen);
		//painter.drawLine(0,drawTraceY,width(),drawTraceY);
		painter.drawEllipse(drawTraceX-2,drawTraceY-1,4,2);
		pen.setColor(QColor::fromRgb(0,0,0));
		pen.setWidth(2);
		painter.setPen(pen);
		painter.drawEllipse(drawTraceX-6,drawTraceY-4,12,8);
	}
}

void TableViewNew3D::mouseMoveEvent(QMouseEvent *evt)
{
	self.m_x = evt->x() / self.m_itemWidth;
	self.m_y = evt->y() / self.m_itemHeight;
	update();
}
void TableViewNew3D::mousePressEvent(QMouseEvent *evt)
{
	self.m_x = evt->x() / self.m_itemWidth;
	self.m_y = evt->y() / self.m_itemHeight;
	if (self.m_y == self.m_rowCount)
	{
		self.m_y = -1;
	}
	currentCell.setX(self.m_x-1);
	currentCell.setY(self.m_y);
	//if (currentCell)
	/*if (self.m_highlightList.size() > self.m_y)
	{
		if (self.m_highlightList.at(self.m_y).size() > self.m_x)
		{
			self.m_highlightList[self.m_y][self.m_x] = 1;
		}
	}*/

	update();
}

void TableViewNew3D::mouseReleaseEvent(QMouseEvent *evt)
{
	Q_UNUSED(evt)
}
void TableViewNew3D::keyPressEvent(QKeyEvent *evt)
{
	if (evt->key() >= Qt::Key_0 && evt->key() <= Qt::Key_9)
	{
		//It's a number key!
		if (!self.m_inEdit)
		{
			self.m_inEdit = true;
		}

		self.m_editText += QString::number(evt->key()-0x30,'f',0);
		update();
	}
	else if (evt->key() == Qt::Key_Period)
	{
		if (!self.m_inEdit)
		{
			self.m_inEdit = true;
			self.m_editText = "0";
		}

		self.m_editText += ".";
		update();
	}
	else if (evt->key() == Qt::Key_Backspace)
	{
		if (self.m_inEdit)
		{
			self.m_editText = self.m_editText.mid(0,self.m_editText.length()-1);
			update();
		}
	}
	else if (evt->key() == Qt::Key_Enter || evt->key() == Qt::Key_Return)
	{
		if (self.m_inEdit)
		{
			self.m_inEdit = false;
			emit itemChangeRequest(currentCell.y(),currentCell.x(),self.m_editText);
			self.m_editText = "";
			update();
		}
	}
	else if (evt->key() == Qt::Key_Escape)
	{
		if (self.m_inEdit)
		{
			self.m_inEdit = false;
			self.m_editText = "";
			update();
		}
	}
	if (evt->key() == Qt::Key_Up)
	{
		if (currentCell.y() > 0 || currentCell.y() == -1)
		{
			if (self.m_inEdit)
			{
				self.m_inEdit = false;
				emit itemChangeRequest(currentCell.y(),currentCell.x(),self.m_editText);
				self.m_editText = "";
			}
			if (currentCell.y() == -1)
			{
				currentCell.setY(self.m_rowCount-1);
			}
			else
			{
				currentCell.setY(currentCell.y()-1);
			}
			self.m_selectionList.clear();
			self.m_selectionList.append(QPair<int,int>(currentCell.x(),currentCell.y()));
			emit currentSelectionChanged(self.m_selectionList);
			update();
			return;
		}
	}
	if (evt->key() == Qt::Key_Down)
	{
		if (currentCell.y() < self.m_rowCount && currentCell.y() != -1)
		{
			if (self.m_inEdit)
			{
				self.m_inEdit = false;
				emit itemChangeRequest(currentCell.y(),currentCell.x(),self.m_editText);
				self.m_editText = "";
			}
			if (currentCell.y() == self.m_rowCount-1)
			{
				currentCell.setY(-1);
				if (currentCell.x() == -1)
				{
					//We're at the bottom cell of the axis, flip over the other axis
					currentCell.setX(0);
				}
			}
			else
			{
				currentCell.setY(currentCell.y()+1);
			}
			self.m_selectionList.clear();
			self.m_selectionList.append(QPair<int,int>(currentCell.x(),currentCell.y()));
			emit currentSelectionChanged(self.m_selectionList);
			update();
			return;
		}
	}
	if (evt->key() == Qt::Key_Left)
	{
		if (currentCell.x() >= 0)
		{
			if (self.m_inEdit)
			{
				self.m_inEdit = false;
				emit itemChangeRequest(currentCell.y(),currentCell.x(),self.m_editText);
				self.m_editText = "";
			}
			if (currentCell.x() == 0 && currentCell.y() == -1)
			{
				//At the leftmost axis cell, flip to the other axis
				currentCell.setY(self.m_rowCount-1);
			}
			currentCell.setX(currentCell.x()-1);
			self.m_selectionList.clear();
			self.m_selectionList.append(QPair<int,int>(currentCell.x(),currentCell.y()));
			emit currentSelectionChanged(self.m_selectionList);
			update();
			return;
		}
	}
	if (evt->key() == Qt::Key_Right)
	{
		if (currentCell.x() < self.m_columnCount-1)
		{
			if (self.m_inEdit)
			{
				self.m_inEdit = false;
				emit itemChangeRequest(currentCell.y(),currentCell.x(),self.m_editText);
				self.m_editText = "";
			}
			currentCell.setX(currentCell.x()+1);
			self.m_selectionList.clear();
			self.m_selectionList.append(QPair<int,int>(currentCell.x(),currentCell.y()));
			emit currentSelectionChanged(self.m_selectionList);
			update();
			return;
		}
	}
	if (self.m_inEdit)
	{
		return;
	}
	for (int i=0;i<self.m_hotkeyMap.size();i++)
	{
		if (self.m_hotkeyMap.at(i).first == evt->key())
		{
			if (self.m_hotkeyMap.at(i).second != Qt::NoModifier)
			{
				if (evt->modifiers() & self.m_hotkeyMap.at(i).second)
				{
					emit hotKeyPressed(evt->key(),self.m_hotkeyMap.at(i).second);
				}
			}
			else
			{
				emit hotKeyPressed(evt->key(),Qt::NoModifier);
			}
		}
	}
	}
